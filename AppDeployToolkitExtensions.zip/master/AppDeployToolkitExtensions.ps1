# 16/12/2021
<#
.SYNOPSIS
	This script is a template that allows you to extend the toolkit with your own custom functions.
    # LICENSE #
    PowerShell App Deployment Toolkit - Provides a set of functions to perform common application deployment tasks on Windows.
    Copyright (C) 2017 - Sean Lillis, Dan Cunningham, Muhammad Mashwani, Aman Motazedian.
    This program is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
    You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.
.DESCRIPTION
	The script is automatically dot-sourced by the AppDeployToolkitMain.ps1 script.
.NOTES
    Toolkit Exit Code Ranges:
    60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
    69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
    70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK
	http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
)

##*===============================================
##* VARIABLE DECLARATION
##*===============================================

# Variables: Script
[string]$appDeployToolkitExtName = 'PSAppDeployToolkitExt'
[string]$appDeployExtScriptFriendlyName = 'App Deploy Toolkit Extensions'
[version]$appDeployExtScriptVersion = [version]'3.8.3'
[string]$appDeployExtScriptDate = '30/09/2020'
[hashtable]$appDeployExtScriptParameters = $PSBoundParameters

##*===============================================
##* FUNCTION LISTINGS
##*===============================================

function Set-RegistryKey_AppInstalled {
	<#
		.SYNOPSIS
		 Detection Method for successful installed program.
		.DESCRIPTION
		 Creates a registry key under HKLM\software\RM\AppStatus. The Key value is set to "Installed" or "Uninstalled"
		 The Variables are from the Deploy-Application.ps1 script.
		 The Function Call has to be made in the POST INSTALLATION part.
	
		 If UninstallOldVersions does not work, you are most likly not complying with the naming standard.
		.PARAMETER Uninstall
			Switch parameter to set the application as uninstalled
		.PARAMETER Remove
			Switch parameter to remove the key, use the Uninstall parameter instead.
		.PARAMETER UninstallOldVersions
			Switch parameter to set the all old versions of the application as uninstalled
			Normaly set in PRE-INSTALLATION after the removal of old versions
		.EXAMPLE
		 Set-registryKey_AppInstalled
	
		 Set-registryKey_AppInstalled -Uninstall
	
		 Set-registryKey_AppInstalled -UninstallOldVersions
		.LINK
		 http://psappdeploytoolkit.com/
	#>	
		[CmdletBinding(DefaultParameterSetName="Uninstalled",SupportsShouldProcess=$True)] 
			Param(
				[parameter(Mandatory = $false,ParameterSetName="Uninstalled")]
				[switch]$Uninstall,
				[parameter(Mandatory = $false,ParameterSetName="Remove")]
				[switch]$Remove,
				[parameter(Mandatory = $false,ParameterSetName="UninstallOldVersions")]
				[switch]$UninstallOldVersions
			)
		if($Uninstall){
			Write-Log -Message "Writing registry detection Method for successful Uninstalled program" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
			if (-not (Test-path -Path "HKLM:\SOFTWARE\RM\AppStatus")) { New-Item -Path "HKLM:\SOFTWARE\RM\AppStatus" }
			Set-ItemProperty -Path "HKLM:\SOFTWARE\RM\AppStatus" -Name "$AppVendor $AppName $AppVersion $AppRevision" -Value "Uninstalled"
			Write-Log -Message "Registry -> $AppVendor $AppName $AppVersion $AppRevision=Uninstalled" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
	
		}elseif($Remove){
			Write-Log -Message "Deleting registry detection Method for program" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
			Remove-ItemProperty -Path "HKLM:\SOFTWARE\RM\AppStatus" -Name "$AppVendor $AppName $AppVersion $AppRevision" -ErrorAction SilentlyContinue
			Write-Log -Message "Registry -> $AppVendor $AppName $AppVersion $AppRevision" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
		}elseif($UninstallOldVersions){
			Write-Log -Message "Writing registry detection Method for successful Uninstalled old versions of the program" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
			$AppCount = 0
			$AppStatus = Get-RegistryKey -Key "HKLM:SOFTWARE\RM\AppStatus"
			foreach ($item in $AppStatus.PSObject.Properties) {
				if ($item.name -like "$AppVendor $AppName *") {
					if ($item.Value -eq "Installed" -and $item.Name -notlike "$AppVendor $AppName $AppVersion $AppRevision") {
						Set-ItemProperty -Path "HKLM:\SOFTWARE\RM\AppStatus" -Name $item.name  -Value "Uninstalled"
						Write-Log -Message "Registry -> $($item.name)=Uninstalled" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
						$AppCount++
					}			
			   }
			}
			if($AppCount -eq 0){
				Write-Log -Message "No old application detection rule found" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
			}elseif ($AppCount -eq 1) {
				Write-Log -Message "1 detection rule set to uninstalled" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
			}else{
				Write-Log -Message "$AppCount detection rules set to uninstalled" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
			}
		}else{
			Write-Log -Message "Writing registry detection Method for successful installed program" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
			if (-not (Test-path -Path "HKLM:\SOFTWARE\RM")) { New-Item -Path "HKLM:\SOFTWARE\RM" }
			if (-not (Test-path -Path "HKLM:\SOFTWARE\RM\AppStatus")) { New-Item -Path "HKLM:\SOFTWARE\RM\AppStatus" }
			Set-ItemProperty -Path "HKLM:\SOFTWARE\RM\AppStatus" -Name "$AppVendor $AppName $AppVersion $AppRevision" -Value "Installed"
			Write-Log -Message "Registry -> $AppVendor $AppName $AppVersion $AppRevision=Installed" -Source 'Set-RegistryKey_AppInstalled' -LogType 'CMTrace'
		}
	}
function Set-FileSecurity {
<#
	.SYNOPSIS
	 Add a User account to the file ACL with the specified file system rights
	.DESCRIPTION
	 Add a User account to the file ACL with the specified file system rights
	.PARAMETER FileName
	 Specify the file/folder name as String.
	.PARAMETER User
	 Specify the user name as String.
	.PARAMETER SecurityIdentifier
	 Specify the SID as String.
	 see this link for well known security identifiers
	 https://support.microsoft.com/da-dk/help/243330/well-known-security-identifiers-in-windows-operating-systems
	.PARAMETER FileSystemRights
	 Specify the FileSystemRights name as String.
	 Run this command to se values
	 [enum]::GetNames("System.Security.AccessControl.FileSystemRights")
	.EXAMPLE 
	 Set-FileSecurity -FileName "C:\Test\New Text Document.txt" -User "brugere" -FileSystemRights "Modify"
	 Set-FileSecurity -FileName "C:\Test\New Text Document.txt" -SecurityIdentifier "S-1-5-32-545" -FileSystemRights "Modify"
    .LINK
     http://psappdeploytoolkit.com/
#>
    [CmdletBinding(SupportsShouldProcess=$True)] 
		Param(
			[parameter(Mandatory = $True)]
			[ValidateNotNullOrEmpty()]
			$FileName,
			[parameter(Mandatory = $True,ParameterSetName="SecurityIdentifier")]
			[ValidateNotNullOrEmpty()]
			$SecurityIdentifier,
			[parameter(Mandatory = $True,ParameterSetName="User")]
			[ValidateNotNullOrEmpty()]
			$User,
			[parameter(Mandatory = $True)]
			[ValidateNotNullOrEmpty()]
			$FileSystemRights
		)

		Write-Log -Message "Granting $User$SecurityIdentifier modify access to: $FileName" -Source "$installPhase" -LogType 'CMTrace'
		$ObjACL = Get-Acl -Path $FileName
		
		$InheritanceFlag = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit, ObjectInherit"
		$PropagationFlag = [System.Security.AccessControl.PropagationFlags]::None
		$ObjType = [System.Security.AccessControl.AccessControlType]::Allow
		
		$ColRights = [System.Security.AccessControl.FileSystemRights]::$FileSystemRights
		if($ColRights.value__ -eq $null){
			Write-Log -Message "The FileSystemRights is not valid" -Source "$installPhase" -LogType 'CMTrace'
			throw [System.Security.AccessControl.PrivilegeNotHeldException] $FileSystemRights
		}
		
		if($($PSCmdlet.ParameterSetName) -eq "SecurityIdentifier"){
			Try{
				$ObjSecurityPrincipal = New-Object System.Security.Principal.SecurityIdentifier($SecurityIdentifier)
				$Username = $($ObjSecurityPrincipal.Translate([System.Security.Principal.NTAccount])).Value
				Write-Log -Message "User name is: $Username" -Source "$installPhase" -LogType 'CMTrace'
			}catch{
				Write-Log -Message "The user name is not valid" -Source "$installPhase" -LogType 'CMTrace'
				throw [System.Security.Principal.IdentityNotMappedException] "The user name is not valid"
			}
		}
		if($($PSCmdlet.ParameterSetName) -eq "User"){
			Try{
				$ObjSecurityPrincipal = New-Object System.Security.Principal.NTAccount($User)
				$SecurityIdentifier = $ObjSecurityPrincipal.Translate([System.Security.Principal.SecurityIdentifier])
				Write-Log -Message "User has SID: $SecurityIdentifier" -Source "$installPhase" -LogType 'CMTrace'
			}catch{
				Write-Log -Message "The user name is not valid" -Source "$installPhase" -LogType 'CMTrace'
				throw [System.Security.Principal.IdentityNotMappedException] "The user name is not valid"
			}
		}	
		
		Try{
			$ObjACE = New-Object System.Security.AccessControl.FileSystemAccessRule($ObjSecurityPrincipal, $ColRights, $InheritanceFlag, $PropagationFlag, $ObjType)
			$ObjACL.AddAccessRule($ObjACE)
			Set-Acl -Path $FileName -AclObject $ObjACL
			Write-Log -Message "Successfull granted $User$SecurityIdentifier modify access to: $FileName" -Source "$installPhase" -LogType 'CMTrace'
		}catch{
			Write-Log -Message "Error Setting the AccessRule on $FileName" -Source "$installPhase" -LogType 'CMTrace'
			throw "Error Setting the AccessRule on $FileName"
		}
	
}

function Firewall_Allow 
{
	<#
    .SYNOPSIS
     Creates a new inbound or outbound firewall rule and adds the rule to the target computer.
    .DESCRIPTION
	 The Firewall_Allow cmdlet creates an inbound or outbound firewall rule and adds the rule to the target computer.
    .PARAMETER Direction
        Specifies that matching firewall rules of the indicated direction are created. This parameter specifies which direction of traffic to match with this rule. The acceptable values for this parameter are: Inbound or Outbound. The default value is Outbound.
    .PARAMETER Remove
        Switch parameter to remove the firewall rule.
    .EXAMPLE
	# Creating Inbound rule
	Firewall_Allow -progPath "\\onerm.dk\NFPdata\Application\AstraiaClient\Produktion\jre\bin\java.exe" -ruleName "Astraia_OneRM_Prod" -Direction Inbound
	# Creating Outbound rule
	Firewall_Allow -progPath "\\onerm.dk\NFPdata\Application\AstraiaClient\Produktion\jre\bin\java.exe" -ruleName "Astraia_OneRM_Prod" -Direction Outbound
	# Remove rule	
	Firewall_Allow -progPath "\\RMAPPS0276.ONERM.DK\AstraiaProdServer$\jre\bin\java.exe" -ruleName "Astraia_OneRM_Prod" -remove
  	.LINK
     http://psappdeploytoolkit.com/
#>	
[CmdletBinding(SupportsShouldProcess=$True)] 
		Param(
		    $progPath, 
			$ruleName,
			[Parameter(Mandatory=$false)]
			[ValidateSet('Outbound','Inbound')]
			[string]$Direction = 'Outbound',
			[switch]$remove
		)
    Begin
    {
    }
    Process
    {
		if($remove -eq $true)
		{
			$IDs = Get-NetFirewallApplicationFilter -Program "$progPath" 
			foreach ($ID in $IDs)
			{
				Remove-NetFirewallRule -Name "$($ID.InstanceID)"
				Write-Log -Message "Removing firewall rule: [$ruleName] $($ID.Program) $($ID.InstanceID)" -Source 'Firewall_Allow' -LogType 'CMTrace' -Severity '1'
			}
		} else {
			if(-not(Get-NetFirewallApplicationFilter -Program $progPath -ErrorAction SilentlyContinue))
			{
				#"UDP", "TCP" | ForEach-Object { New-NetFirewallRule -DisplayName $ruleName -Direction Outbound -Profile Any -Program $progPath -Action Allow -Protocol $_ }
				New-NetFirewallRule -DisplayName $ruleName -Direction $Direction -Profile Any -Program $progPath -Action Allow -Protocol Any
				Write-Log -Message "Creating firewall rulename: $ruleName - [Path]: $progPath" -Source 'Firewall_Allow' -LogType 'CMTrace' -Severity '1'
				Clear-Variable ruleName
			} else {
				Write-Log -Message "Firewall rule already exist: $ruleName" -Source 'Firewall_Allow' -LogType 'CMTrace' -Severity '2'
			}
		}
    }
    End
    {
    }
}


function RemoveShortcuts  
{  
	<#
    .SYNOPSIS
    RemoveShortcuts remove shortcuts from Public desktop
    .DESCRIPTION
	 The Firewall_Allow cmdlet creates an inbound or outbound firewall rule and adds the rule to the target computer.
    .PARAMETER Direction
        Specifies that matching firewall rules of the indicated direction are created. This parameter specifies which direction of traffic to match with this rule. The acceptable values for this parameter are: Inbound or Outbound. The default value is Outbound.
    .PARAMETER Remove
        Switch parameter to remove the firewall rule.
    .EXAMPLE
	# Create before snapshot
	RemoveShortcuts
	# Do the installation

	# Run clean up
	RemoveShortcuts -SnapshotIsTaken
  	.LINK
     http://psappdeploytoolkit.com/
#>
Param(
	[switch]$SnapshotIsTaken
)
    # 'Tag Sapshot' af genveje der ligger i "C:\Users\Public\Desktop" efter installationen
    if ($SnapshotIsTaken) {
        $AfterShortcuts = Get-ChildItem -Path "$($env:PUBLIC)\Desktop\*.lnk" -Recurse
		if ($BeforeShortcuts.count -lt $AfterShortcuts.count) {
            if($($BeforeShortcuts.count) -eq '0'){
                $ShortCutDifference = $AfterShortcuts
            } else {
                $ShortCutDifference = Compare-Object $BeforeShortcuts $AfterShortcuts -Property FullName 
            }
			foreach ($Difference in $ShortCutDifference) {
				# Fjern nye genveje fra "C:\Users\Public\Desktop"
				Write-Log -Message "Removing: $($Difference.FullName)" -Source 'RemoveShortcuts' -LogType 'CMTrace' -Severity '1'
				Remove-Item -Path "$($Difference.FullName)" -Verbose
			}			
    	} else {
            Write-Log -Message "No new shortcuts on publics desktop to remove" -Source 'RemoveShortcuts' -LogType 'CMTrace' -Severity '1'
        }
        $folders = Get-ChildItem -Path "$($env:PUBLIC)\Desktop" -Directory
        foreach ($folder in $folders.FullName)
        {
            $folder.FullName
            if( (Get-ChildItem $folder | Measure-Object).Count -eq 0)
            {
                Remove-Item -Path $folder
            }
        }
        Remove-Variable BeforeShortcuts -Scope Global -ErrorAction SilentlyContinue
	}	
	else
    {
        $Global:BeforeShortcuts = Get-ChildItem -Path "$($env:PUBLIC)\Desktop\*.lnk" -Recurse
        Write-Log -Message "Creating a shortcut snapshot of public desktop for cleanup later [$($BeforeShortcuts.count)]" -Source 'RemoveShortcuts' -LogType 'CMTrace' -Severity '1'
	}
}

##*===============================================
##* END FUNCTION LISTINGS
##*===============================================

##*===============================================
##* SCRIPT BODY
##*===============================================

If ($scriptParentPath) {
	Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] dot-source invoked by [$(((Get-Variable -Name MyInvocation).Value).ScriptName)]" -Source $appDeployToolkitExtName
} Else {
	Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] invoked directly" -Source $appDeployToolkitExtName
}

##*===============================================
##* END SCRIPT BODY
##*===============================================
